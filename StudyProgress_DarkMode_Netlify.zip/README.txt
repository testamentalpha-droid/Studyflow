Study Progress — Dark Mode Upgrade

Drop this folder into Netlify Drop.
Dark mode is available from the moon/sun button in the header.
The selected theme is saved in the browser.
All existing app data/features are preserved.
